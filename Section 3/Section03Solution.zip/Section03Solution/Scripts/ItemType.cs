namespace Holistic3D.Inventory {

    public enum ItemType {

        Weapon,
        Consumable,
        Armor,
        Material,
        QuestItem
    }
}