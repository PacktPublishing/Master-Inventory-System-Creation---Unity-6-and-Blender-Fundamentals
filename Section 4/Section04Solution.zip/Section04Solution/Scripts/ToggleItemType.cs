using UnityEngine;

namespace Holistic3D.Inventory {

    public class ToggleItemType : MonoBehaviour {

        public ItemType toggleItemType;
    }
}