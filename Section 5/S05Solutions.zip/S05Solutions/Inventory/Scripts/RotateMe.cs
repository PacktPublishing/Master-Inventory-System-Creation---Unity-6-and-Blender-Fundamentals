using UnityEngine;

public class RotateMe : MonoBehaviour {

    void Update() {

        this.transform.Rotate(0.0f, 1.0f, 0.0f);
    }
}
